---
title: Plugins

access:
    admin.plugins: true
    admin.super: true
---
